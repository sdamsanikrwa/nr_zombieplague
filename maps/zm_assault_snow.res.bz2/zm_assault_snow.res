gfx/env/spaceup.tga
gfx/env/spacedn.tga
gfx/env/spacelf.tga
gfx/env/spacert.tga
gfx/env/spaceft.tga
gfx/env/spacebk.tga
sprites/glow01.spr
sound/buttons/button5.wav
